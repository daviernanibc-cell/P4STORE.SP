# P4 STORE (Etapa 2: banco, contas e painel)
Node 20+. `npm install`, configure o Supabase (abaixo), `npm run dev`, `npm run lint`.

## Configurar o Supabase
1. Em supabase.com crie um projeto (região São Paulo, se disponível).
2. SQL Editor > New query: cole TODO o arquivo `supabase/schema.sql` e execute. Cria tabelas, RLS, gatilhos e o bucket `product-images`.
3. Project Settings > API: copie a Project URL e a chave anon/publishable para `.env.local` (modelo em `.env.example`).
   Não use a chave service_role em nenhum lugar desta etapa.
4. Authentication > URL Configuration: Site URL = http://localhost:3000 (depois, o domínio publicado) e adicione o mesmo em Redirect URLs.
   Authentication > Providers > Email: mantenha "Confirm email" ligado em produção.
5. Rode `npm run dev`, crie sua conta em /cadastro (confirme o e-mail) e, no SQL Editor, execute com o SEU e-mail:
   `update public.profiles set role = 'admin' where email = 'SEU_EMAIL';`
   Ninguém consegue virar admin pelo site: o papel só muda pelo SQL Editor.
6. Entre e acesse /admin.

## Testes de permissão (faça antes de publicar)
- Visitante: /admin e /conta redirecionam ao login.
- Cliente comum: /admin dá 404; no SQL Editor, `select` como outro usuário não retorna endereços/pedidos alheios.
- Cliente não consegue editar produtos nem enviar fotos (RLS e Storage).
- Admin cria produto com fotos e estoque; aparece na home e no catálogo; excluir remove as fotos.

## Fora desta etapa
Criação de pedidos pelo checkout, pagamento (Mercado Pago), frete e etiquetas (Melhor Envio), prazos editáveis no painel: Etapa 3.
Faturamento e pedidos no painel ficam zerados até o checkout existir.
