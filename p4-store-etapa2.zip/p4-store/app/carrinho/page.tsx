"use client";
import Link from "next/link"; import { useCart, keyOf } from "@/lib/cart"; import { brl } from "@/lib/format"; import DeliveryEstimate from "@/components/DeliveryEstimate";
export default function Cart() {
  const { items, setQty, remove, subtotal } = useCart();
  if (!items.length) return <div className="mt-10"><h1 className="font-display text-4xl">Carrinho vazio</h1><Link href="/produtos" className="btn mt-5">Ver produtos</Link></div>;
  return (<div className="mt-8 grid gap-8 md:grid-cols-[1fr_320px]"><div><h1 className="font-display text-4xl">Carrinho</h1>
    <ul className="mt-4 divide-y divide-bone/10">{items.map(i => { const k = keyOf(i); return (<li key={k} className="flex items-center gap-4 py-4">
      <div className="min-w-0 flex-1"><p className="font-semibold">{i.name}</p><p className="text-sm text-bone/60">Tamanho {i.size} · {i.color}</p><p>{brl(i.price)}</p></div>
      <div className="flex items-center border border-bone/30"><button className="px-3 py-2" onClick={() => setQty(k, i.qty - 1)} aria-label="Diminuir">−</button><span className="w-8 text-center">{i.qty}</span><button className="px-3 py-2" onClick={() => setQty(k, i.qty + 1)} aria-label="Aumentar">+</button></div>
      <button className="text-sm underline" onClick={() => remove(k)}>Remover</button></li>); })}</ul></div>
    <aside className="space-y-5 self-start bg-coal p-5"><p className="flex justify-between text-lg"><span>Subtotal</span><span className="font-semibold">{brl(subtotal)}</span></p>
      <DeliveryEstimate /><p className="text-sm text-bone/60">Frete real: cotação via Melhor Envio (Etapa 3).</p>
      <button className="btn w-full" disabled>Finalizar compra (Etapa 3)</button>
      <p className="text-xs text-bone/50">Checkout, endereço completo e pagamento serão ativados na Etapa 3, com Mercado Pago.</p></aside></div>);
}
