"use server";
import { redirect } from "next/navigation"; import { z } from "zod"; import { supabaseServer } from "@/lib/supabase/server";
const safeNext = (n: string) => (n.startsWith("/") && !n.startsWith("//") ? n : "");
export async function login(fd: FormData) {
  const next = safeNext(String(fd.get("next") ?? "")); const q = next ? `&next=${encodeURIComponent(next)}` : "";
  const s = await supabaseServer();
  const { error } = await s.auth.signInWithPassword({ email: String(fd.get("email") ?? ""), password: String(fd.get("password") ?? "") });
  if (error) redirect(`/login?erro=credenciais${q}`);
  redirect(next || "/conta");
}
const signupSchema = z.object({ name: z.string().trim().min(2).max(100), email: z.string().trim().email(), password: z.string().min(8).max(72) });
export async function signup(fd: FormData) {
  const r = signupSchema.safeParse(Object.fromEntries(fd)); if (!r.success) redirect("/cadastro?erro=dados");
  const s = await supabaseServer();
  const { data, error } = await s.auth.signUp({ email: r.data.email, password: r.data.password, options: { data: { full_name: r.data.name } } });
  if (error) redirect("/cadastro?erro=cadastro");
  if (data.session) redirect("/conta");
  redirect("/login?ok=confirme");
}
export async function logout() { const s = await supabaseServer(); await s.auth.signOut(); redirect("/"); }
