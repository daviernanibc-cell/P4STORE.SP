import type { Metadata } from "next"; import { Anton, Inter } from "next/font/google"; import "./globals.css";
import { CartProvider } from "@/lib/cart"; import Header from "@/components/Header"; import Footer from "@/components/Footer";
const display = Anton({ weight: "400", subsets: ["latin"], variable: "--font-display" });
const body = Inter({ subsets: ["latin"], variable: "--font-body" });
export const metadata: Metadata = { title: "P4 STORE", description: "Streetwear: camisetas, calças, moletons, jaquetas, tênis e acessórios." };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)
    return <html lang="pt-BR"><body style={{ background: "#0d0a0a", color: "#ececec", fontFamily: "sans-serif", padding: 24 }}><h1>P4 STORE: falta configurar o Supabase</h1><p>Crie o arquivo .env.local a partir de .env.example e reinicie. Veja o README.</p></body></html>;
  return (<html lang="pt-BR" className={`${display.variable} ${body.variable}`}><body><CartProvider><Header /><main className="mx-auto max-w-6xl px-4">{children}</main><Footer /></CartProvider></body></html>);
}
