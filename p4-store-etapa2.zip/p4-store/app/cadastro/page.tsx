import Link from "next/link"; import { signup } from "@/app/auth/actions";
const ERR: Record<string, string> = { dados: "Confira os campos. A senha precisa ter pelo menos 8 caracteres.", cadastro: "Não foi possível criar a conta. Se você já tem cadastro, entre." };
export default async function Signup({ searchParams }: { searchParams: Promise<{ erro?: string }> }) {
  const sp = await searchParams;
  return (<div className="mx-auto mt-10 max-w-sm"><h1 className="font-display text-4xl">Criar conta</h1>
    {sp.erro && ERR[sp.erro] && <p role="alert" className="mt-4 border border-pepper p-3 text-sm">{ERR[sp.erro]}</p>}
    <form action={signup} className="mt-6 space-y-4">
      <label className="block text-sm">Nome completo<input name="name" required minLength={2} autoComplete="name" className="input mt-1" /></label>
      <label className="block text-sm">E-mail<input name="email" type="email" required autoComplete="email" className="input mt-1" /></label>
      <label className="block text-sm">Senha (mínimo 8 caracteres)<input name="password" type="password" required minLength={8} autoComplete="new-password" className="input mt-1" /></label>
      <button className="btn w-full">Criar conta</button></form>
    <p className="mt-5 text-sm">Já tem conta? <Link href="/login" className="underline">Entrar</Link></p></div>);
}
