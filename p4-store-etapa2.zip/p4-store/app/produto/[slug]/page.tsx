import { notFound } from "next/navigation"; import { getProductBySlug } from "@/lib/products"; import { effective, imageUrl } from "@/lib/product-types"; import { brl } from "@/lib/format";
import AddToCart from "@/components/AddToCart"; import DeliveryEstimate from "@/components/DeliveryEstimate";
export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const p = await getProductBySlug((await params).slug); if (!p) notFound();
  return (<div className="mt-6 grid gap-8 md:grid-cols-2">
    <div className="space-y-3">{p.images.length ? p.images.map((im, i) => <img key={im} src={imageUrl(im)} alt={`${p.name}, foto ${i + 1}`} className="w-full bg-coal object-cover" />)
      : <div className="relative aspect-[4/5] bg-coal"><div className="absolute inset-0 grid place-items-center font-display text-8xl text-bone/10">P4</div></div>}</div>
    <div className="space-y-6 self-start md:sticky md:top-32"><div><p className="text-sm text-bone/60">{p.brand} · {p.category}</p><h1 className="font-display text-4xl">{p.name}</h1>
      <p className="mt-2 text-2xl">{p.promoPrice && <span className="mr-3 text-bone/50 line-through">{brl(p.price)}</span>}{brl(effective(p))}</p></div>
      <p className="whitespace-pre-line text-bone/80">{p.description}</p><AddToCart p={p} />
      <div className="border-t border-bone/10 pt-5"><p className="mb-2 font-semibold">Prazo de entrega</p><DeliveryEstimate /></div></div>
  </div>);
}
