import Link from "next/link"; import { listProducts } from "@/lib/products"; import type { Product } from "@/lib/product-types"; import ProductCard from "@/components/ProductCard";
function Row({ title, items }: { title: string; items: Product[] }) {
  if (!items.length) return null;
  return (<section className="mt-14"><h2 className="font-display text-3xl">{title}</h2>
    <div className="mt-5 grid grid-cols-2 gap-4 md:grid-cols-4">{items.slice(0, 8).map(p => <ProductCard key={p.id} p={p} />)}</div></section>);
}
export default async function Home() {
  const all = await listProducts();
  return (<>
    <section className="mt-6 flex min-h-[60vh] flex-col justify-end bg-coal p-6 sm:p-12">
      <h1 className="font-display text-6xl leading-none sm:text-8xl">Rua é<br />o nosso ateliê.</h1>
      <p className="mt-4 max-w-md text-bone/70">Roupas, tênis e acessórios P4, feitos para quem se veste para circular.</p>
      <div className="mt-6 flex gap-3"><Link href="/produtos" className="btn">Ver coleção</Link><Link href="/produtos?categoria=Tênis" className="btn-line">Tênis</Link></div>
    </section>
    {!all.length && <p className="mt-10 text-bone/70">A coleção está sendo montada. Volte em breve.</p>}
    <Row title="Em destaque" items={all.filter(p => p.tags.includes("destaque"))} />
    <Row title="Lançamentos" items={all.filter(p => p.tags.includes("lancamento"))} />
    <Row title="Mais vendidos" items={all.filter(p => p.tags.includes("maisvendido"))} />
    <Row title="Ofertas especiais" items={all.filter(p => p.promoPrice)} />
  </>);
}
