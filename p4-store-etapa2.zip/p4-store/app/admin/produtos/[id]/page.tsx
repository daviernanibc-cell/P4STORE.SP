import { notFound } from "next/navigation"; import { requireAdmin } from "@/lib/supabase/server"; import ProductForm from "@/components/ProductForm";
export default async function EditProduct({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ erro?: string }> }) {
  const { id } = await params; const sp = await searchParams; const { s } = await requireAdmin();
  const { data: p } = await s.from("products").select("*, product_variants(size,color,stock)").eq("id", id).maybeSingle(); if (!p) notFound();
  return (<div><h1 className="font-display text-4xl">Editar produto</h1>{sp.erro && <p role="alert" className="my-4 border border-pepper p-3 text-sm">{sp.erro}</p>}
    <div className="mt-6"><ProductForm initial={{ id: p.id, name: p.name, brand: p.brand, category: p.category, description: p.description, price: String(p.price), promo_price: p.promo_price == null ? "" : String(p.promo_price), active: p.active, tags: p.tags, images: p.images, variants: p.product_variants }} /></div></div>);
}
