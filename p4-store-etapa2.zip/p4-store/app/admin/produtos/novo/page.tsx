import ProductForm from "@/components/ProductForm";
export default async function NewProduct({ searchParams }: { searchParams: Promise<{ erro?: string }> }) {
  const sp = await searchParams;
  return (<div><h1 className="font-display text-4xl">Novo produto</h1>{sp.erro && <p role="alert" className="my-4 border border-pepper p-3 text-sm">{sp.erro}</p>}
    <div className="mt-6"><ProductForm initial={{ id: null, name: "", brand: "P4", category: "", description: "", price: "", promo_price: "", active: true, tags: [], images: [], variants: [{ size: "", color: "", stock: 0 }] }} /></div></div>);
}
