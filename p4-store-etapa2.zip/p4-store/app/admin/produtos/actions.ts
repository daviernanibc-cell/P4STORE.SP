"use server";
import { redirect } from "next/navigation"; import { z } from "zod"; import { requireAdmin } from "@/lib/supabase/server"; import { CATEGORIES } from "@/lib/product-types";
const schema = z.object({
  id: z.string().uuid().nullable(),
  name: z.string().trim().min(2, "Informe o nome do produto.").max(120), brand: z.string().trim().min(1, "Informe a marca.").max(60),
  category: z.enum(CATEGORIES, { message: "Escolha uma categoria." }), description: z.string().max(4000),
  price: z.coerce.number({ message: "Preço inválido." }).positive("Informe o preço."),
  promo_price: z.preprocess(v => (v === "" || v == null ? null : Number(v)), z.number({ message: "Preço promocional inválido." }).positive().nullable()),
  active: z.boolean(), tags: z.array(z.enum(["destaque", "lancamento", "maisvendido"])), images: z.array(z.string().regex(/^products\/[\w.-]+$/)).max(8, "No máximo 8 fotos."),
  variants: z.array(z.object({ size: z.string().trim().min(1).max(10), color: z.string().trim().min(1).max(30), stock: z.coerce.number().int().min(0) })).min(1, "Adicione ao menos uma variação (tamanho e cor)."),
}).refine(d => d.promo_price == null || d.promo_price < d.price, { message: "O preço promocional deve ser menor que o preço." });
const slugify = (t: string) => t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60);
export async function saveProduct(fd: FormData) {
  const { s } = await requireAdmin();
  let raw: unknown = null; try { raw = JSON.parse(String(fd.get("payload"))); } catch { /* inválido */ }
  const rid = (raw as { id?: string } | null)?.id; const back = (m: string) => redirect(`${rid ? `/admin/produtos/${rid}` : "/admin/produtos/novo"}?erro=${encodeURIComponent(m)}`);
  const r = schema.safeParse(raw); if (!r.success) return back(r.error.issues[0].message);
  const d = r.data;
  const keys = d.variants.map(v => `${v.size.toLowerCase()}|${v.color.toLowerCase()}`); if (new Set(keys).size !== keys.length) return back("Há variações repetidas (mesmo tamanho e cor).");
  const row = { name: d.name, brand: d.brand, category: d.category, description: d.description, price: d.price, promo_price: d.promo_price, active: d.active, tags: d.tags, images: d.images };
  let id = d.id;
  if (id) { const { error } = await s.from("products").update(row).eq("id", id); if (error) return back("Não foi possível salvar o produto.");
  } else { const { data, error } = await s.from("products").insert({ ...row, slug: `${slugify(d.name) || "produto"}-${crypto.randomUUID().slice(0, 6)}` }).select("id").single();
    if (error || !data) return back("Não foi possível criar o produto."); id = data.id; }
  const rows = d.variants.map(v => ({ product_id: id, size: v.size, color: v.color, stock: v.stock }));
  const up = await s.from("product_variants").upsert(rows, { onConflict: "product_id,size,color" }); if (up.error) return back("Produto salvo, mas o estoque falhou. Tente salvar de novo.");
  const { data: ex } = await s.from("product_variants").select("id,size,color").eq("product_id", id!);
  const keep = new Set(d.variants.map(v => `${v.size}|${v.color}`)); const drop = (ex ?? []).filter(v => !keep.has(`${v.size}|${v.color}`)).map(v => v.id);
  if (drop.length) await s.from("product_variants").delete().in("id", drop);
  redirect("/admin/produtos?ok=Produto salvo.");
}
export async function deleteProduct(fd: FormData) {
  const { s } = await requireAdmin(); const id = z.string().uuid().safeParse(fd.get("id")); if (!id.success) redirect("/admin/produtos");
  const { data } = await s.from("products").select("images").eq("id", id.data).single();
  if (data?.images?.length) await s.storage.from("product-images").remove(data.images);
  const { error } = await s.from("products").delete().eq("id", id.data);
  redirect(`/admin/produtos?${error ? "erro=Não foi possível excluir." : "ok=Produto excluído."}`);
}
