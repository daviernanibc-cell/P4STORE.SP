import Link from "next/link"; import { requireAdmin } from "@/lib/supabase/server"; import { brl } from "@/lib/format"; import DeleteProductButton from "@/components/DeleteProductButton";
export default async function AdminProducts({ searchParams }: { searchParams: Promise<{ ok?: string; erro?: string }> }) {
  const sp = await searchParams; const { s } = await requireAdmin();
  const { data } = await s.from("products").select("id, name, category, price, promo_price, active, product_variants(stock)").order("created_at", { ascending: false });
  return (<div><div className="flex items-center justify-between"><h1 className="font-display text-4xl">Produtos</h1><Link href="/admin/produtos/novo" className="btn">Novo produto</Link></div>
    {sp.ok && <p role="status" className="mt-4 border border-bone/30 p-3 text-sm">{sp.ok}</p>}{sp.erro && <p role="alert" className="mt-4 border border-pepper p-3 text-sm">{sp.erro}</p>}
    {data?.length ? <div className="mt-6 overflow-x-auto"><table className="w-full text-left text-sm"><thead className="text-bone/60"><tr><th className="py-2">Produto</th><th>Categoria</th><th>Preço</th><th>Estoque</th><th>Status</th><th></th></tr></thead>
      <tbody className="divide-y divide-bone/10">{data.map(p => <tr key={p.id}><td className="py-3 font-semibold">{p.name}</td><td>{p.category}</td><td>{brl(Number(p.promo_price ?? p.price))}</td>
        <td>{(p.product_variants as { stock: number }[]).reduce((a, v) => a + v.stock, 0)} un.</td><td>{p.active ? "Visível" : "Oculto"}</td>
        <td className="flex gap-4 py-3"><Link href={`/admin/produtos/${p.id}`} className="underline">Editar</Link><DeleteProductButton id={p.id} name={p.name} /></td></tr>)}</tbody></table></div>
      : <p className="mt-6 text-bone/70">Nenhum produto cadastrado. Comece pelo botão "Novo produto".</p>}</div>);
}
