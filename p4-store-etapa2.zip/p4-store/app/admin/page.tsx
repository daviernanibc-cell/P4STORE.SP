import { requireAdmin } from "@/lib/supabase/server"; import { brl } from "@/lib/format";
export default async function Dashboard() {
  const { s } = await requireAdmin(); const head = { count: "exact" as const, head: true };
  const [p, o, c, paid, pend, low, rev] = await Promise.all([
    s.from("products").select("id", head), s.from("orders").select("id", head), s.from("profiles").select("id", head).eq("role", "customer"),
    s.from("orders").select("id", head).eq("payment_status", "aprovado"), s.from("orders").select("id", head).eq("payment_status", "pendente"),
    s.from("product_variants").select("size, color, stock, products(name)").lte("stock", 2).order("stock").limit(20), s.from("orders").select("total").eq("payment_status", "aprovado")]);
  const revenue = (rev.data ?? []).reduce((a, r) => a + Number(r.total), 0);
  const cards: [string, string | number][] = [["Faturamento (pagamentos aprovados)", brl(revenue)], ["Pedidos", o.count ?? 0], ["Pagamentos aprovados", paid.count ?? 0], ["Pagamentos pendentes", pend.count ?? 0], ["Produtos", p.count ?? 0], ["Clientes", c.count ?? 0]];
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const lowRows = (low.data ?? []) as any[];
  return (<div><h1 className="font-display text-4xl">Resumo</h1>
    <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-3">{cards.map(([l, v]) => <div key={l} className="bg-coal p-4"><p className="text-sm text-bone/60">{l}</p><p className="mt-1 text-2xl font-semibold">{v}</p></div>)}</div>
    <p className="mt-3 text-sm text-bone/60">Os números vêm do banco. Pedidos e pagamentos passam a aparecer quando o checkout for ativado (Etapa 3).</p>
    <h2 className="mt-10 font-display text-2xl">Estoque baixo (2 ou menos)</h2>
    {lowRows.length ? <ul className="mt-3 divide-y divide-bone/10 text-sm">{lowRows.map((v, i) => <li key={i} className="flex justify-between py-2"><span>{v.products?.name} · {v.size} · {v.color}</span><span className={v.stock === 0 ? "text-pepper" : ""}>{v.stock} un.</span></li>)}</ul> : <p className="mt-3 text-bone/70">Nenhuma variação com estoque baixo.</p>}</div>);
}
