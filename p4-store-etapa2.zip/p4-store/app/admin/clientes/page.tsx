import { requireAdmin } from "@/lib/supabase/server"; import { brl } from "@/lib/format";
export default async function AdminCustomers() {
  const { s } = await requireAdmin();
  const [{ data: cs }, { data: addrs }, { data: orders }] = await Promise.all([
    s.from("profiles").select("id, full_name, email, phone, created_at").eq("role", "customer").order("created_at", { ascending: false }),
    s.from("addresses").select("*"), s.from("orders").select("user_id, total, payment_status")]);
  return (<div><h1 className="font-display text-4xl">Clientes</h1>
    {cs?.length ? <ul className="mt-6 divide-y divide-bone/10">{cs.map(c => { const mine = (orders ?? []).filter(o => o.user_id === c.id); const spent = mine.filter(o => o.payment_status === "aprovado").reduce((a, o) => a + Number(o.total), 0); const ad = (addrs ?? []).filter(a => a.user_id === c.id);
      return (<li key={c.id} className="py-4 text-sm"><p className="font-semibold">{c.full_name || "Sem nome"}</p><p className="text-bone/70">{c.email}{c.phone ? ` · ${c.phone}` : ""}</p>
        <p className="text-bone/70">{mine.length} pedido(s) · {brl(spent)} em compras aprovadas · cliente desde {new Date(c.created_at).toLocaleDateString("pt-BR")}</p>
        {ad.length > 0 && <details className="mt-1"><summary className="cursor-pointer underline">Endereços ({ad.length})</summary><ul className="mt-2 space-y-1 text-bone/80">{ad.map(a => <li key={a.id}>{a.street}, {a.number}{a.complement ? ` · ${a.complement}` : ""} · {a.district} · {a.city}/{a.uf} · CEP {a.cep}</li>)}</ul></details>}</li>); })}</ul>
      : <p className="mt-6 text-bone/70">Nenhum cliente cadastrado ainda.</p>}</div>);
}
