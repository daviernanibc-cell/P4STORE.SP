"use server";
import { redirect } from "next/navigation"; import { z } from "zod"; import { requireAdmin } from "@/lib/supabase/server"; import { STATUSES } from "@/lib/order-status";
export async function updateOrderStatus(fd: FormData) {
  const { s } = await requireAdmin();
  const r = z.object({ id: z.string().uuid(), status: z.enum(STATUSES) }).safeParse(Object.fromEntries(fd)); if (!r.success) redirect("/admin/pedidos");
  const { error } = await s.from("orders").update({ status: r.data.status }).eq("id", r.data.id);
  redirect(`/admin/pedidos/${r.data.id}?${error ? "erro=Não foi possível atualizar." : "ok=Status atualizado."}`);
}
