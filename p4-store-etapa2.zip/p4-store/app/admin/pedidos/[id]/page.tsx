import { notFound } from "next/navigation"; import { requireAdmin } from "@/lib/supabase/server"; import { brl } from "@/lib/format"; import { STATUSES, STATUS_LABEL, PAY_LABEL } from "@/lib/order-status"; import { updateOrderStatus } from "../actions";
type Item = { id: string; product_name: string; size: string; color: string; qty: number; unit_price: number };
export default async function AdminOrder({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ ok?: string; erro?: string }> }) {
  const { id } = await params; const sp = await searchParams; const { s } = await requireAdmin();
  const { data: o } = await s.from("orders").select("*, order_items(*)").eq("id", id).maybeSingle(); if (!o) notFound();
  return (<div className="max-w-2xl space-y-8"><div><h1 className="font-display text-4xl">Pedido {o.id.slice(0, 8)}</h1><p className="text-sm text-bone/60">{new Date(o.created_at).toLocaleString("pt-BR")} · Pagamento: {PAY_LABEL[o.payment_status]}</p></div>
    {sp.ok && <p role="status" className="border border-bone/30 p-3 text-sm">{sp.ok}</p>}{sp.erro && <p role="alert" className="border border-pepper p-3 text-sm">{sp.erro}</p>}
    <form action={updateOrderStatus} className="flex items-end gap-3"><input type="hidden" name="id" value={o.id} />
      <label className="flex-1 text-sm">Status do pedido<select name="status" defaultValue={o.status} className="input mt-1">{STATUSES.map(x => <option key={x} value={x}>{STATUS_LABEL[x]}</option>)}</select></label><button className="btn">Atualizar</button></form>
    <section><h2 className="font-display text-2xl">Entrega</h2><dl className="mt-3 grid gap-1 text-sm sm:grid-cols-2">
      {[["Comprador", o.customer_name], ["Telefone", o.customer_phone ?? "não informado"], ["CEP", o.ship_cep], ["Rua", o.ship_street], ["Número", o.ship_number], ["Bairro", o.ship_district], ["Município", o.ship_city], ["Estado", o.ship_uf], ["Complemento", o.ship_complement ?? "sem complemento"], ["Rastreio", o.tracking_code ?? "ainda sem código"]].map(([k, v]) => <div key={k} className="flex gap-2"><dt className="text-bone/60">{k}:</dt><dd>{v}</dd></div>)}</dl></section>
    <section><h2 className="font-display text-2xl">Produtos</h2><ul className="mt-3 divide-y divide-bone/10 text-sm">{(o.order_items as Item[]).map(i => <li key={i.id} className="flex justify-between py-2"><span>{i.qty}× {i.product_name} · tam. {i.size} · {i.color}</span><span>{brl(i.qty * Number(i.unit_price))}</span></li>)}</ul>
      <p className="mt-3 text-right text-sm">Frete {brl(Number(o.shipping_cost))} · <span className="font-semibold">Total {brl(Number(o.total))}</span></p></section></div>);
}
