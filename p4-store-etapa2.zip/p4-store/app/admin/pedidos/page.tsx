import Link from "next/link"; import { requireAdmin } from "@/lib/supabase/server"; import { brl } from "@/lib/format"; import { STATUS_LABEL, PAY_LABEL } from "@/lib/order-status";
export default async function AdminOrders() {
  const { s } = await requireAdmin();
  const { data } = await s.from("orders").select("id, created_at, status, payment_status, total, customer_name").order("created_at", { ascending: false }).limit(200);
  return (<div><h1 className="font-display text-4xl">Pedidos</h1>
    {data?.length ? <div className="mt-6 overflow-x-auto"><table className="w-full text-left text-sm"><thead className="text-bone/60"><tr><th className="py-2">Pedido</th><th>Data</th><th>Cliente</th><th>Total</th><th>Pagamento</th><th>Status</th></tr></thead>
      <tbody className="divide-y divide-bone/10">{data.map(o => <tr key={o.id}><td className="py-3"><Link href={`/admin/pedidos/${o.id}`} className="underline">{o.id.slice(0, 8)}</Link></td><td>{new Date(o.created_at).toLocaleDateString("pt-BR")}</td><td>{o.customer_name}</td><td>{brl(Number(o.total))}</td><td>{PAY_LABEL[o.payment_status]}</td><td>{STATUS_LABEL[o.status]}</td></tr>)}</tbody></table></div>
      : <p className="mt-6 text-bone/70">Nenhum pedido ainda. Os pedidos serão criados pelo checkout (Etapa 3).</p>}</div>);
}
