import Link from "next/link"; import { requireAdmin } from "@/lib/supabase/server";
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin();
  return (<div className="mt-6"><nav className="flex gap-5 overflow-x-auto border-b border-bone/10 pb-3 text-sm font-semibold" aria-label="Painel">
    {[["/admin", "Resumo"], ["/admin/produtos", "Produtos"], ["/admin/pedidos", "Pedidos"], ["/admin/clientes", "Clientes"]].map(([h, l]) => <Link key={h} href={h} className="whitespace-nowrap hover:text-pepper">{l}</Link>)}</nav>
    <div className="mt-6">{children}</div></div>);
}
