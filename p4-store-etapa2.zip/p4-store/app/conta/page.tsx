import { requireUser } from "@/lib/supabase/server"; import { logout } from "@/app/auth/actions"; import { saveProfile, addAddress, deleteAddress } from "./actions";
import { brl } from "@/lib/format"; import { STATUS_LABEL, PAY_LABEL } from "@/lib/order-status";
type Item = { id: string; product_name: string; size: string; color: string; qty: number; unit_price: number };
export default async function Account({ searchParams }: { searchParams: Promise<{ erro?: string; ok?: string }> }) {
  const sp = await searchParams; const { s, user } = await requireUser();
  const [{ data: prof }, { data: addrs }, { data: orders }] = await Promise.all([
    s.from("profiles").select("full_name, phone, email").eq("id", user.id).single(),
    s.from("addresses").select("*").eq("user_id", user.id).order("created_at"),
    s.from("orders").select("*, order_items(*)").eq("user_id", user.id).order("created_at", { ascending: false })]);
  const f = (n: string, l: string, req = true, ac?: string) => <label className="block text-sm">{l}<input name={n} required={req} autoComplete={ac} className="input mt-1" /></label>;
  return (<div className="mt-8 space-y-12"><div className="flex items-center justify-between"><h1 className="font-display text-4xl">Minha conta</h1>
    <form action={logout}><button className="btn-line">Sair</button></form></div>
    {sp.erro && <p role="alert" className="border border-pepper p-3 text-sm">{sp.erro}</p>}{sp.ok && <p role="status" className="border border-bone/30 p-3 text-sm">{sp.ok}</p>}
    <section><h2 className="font-display text-2xl">Dados pessoais</h2><p className="text-sm text-bone/60">{prof?.email}</p>
      <form action={saveProfile} className="mt-4 grid max-w-md gap-4">
        <label className="block text-sm">Nome<input name="full_name" required defaultValue={prof?.full_name ?? ""} className="input mt-1" /></label>
        <label className="block text-sm">Telefone<input name="phone" defaultValue={prof?.phone ?? ""} autoComplete="tel" className="input mt-1" /></label><button className="btn">Salvar dados</button></form></section>
    <section><h2 className="font-display text-2xl">Endereços</h2>
      {addrs?.length ? <ul className="mt-4 grid gap-3 sm:grid-cols-2">{addrs.map(a => <li key={a.id} className="bg-coal p-4 text-sm">
        <p className="font-semibold">{a.label || "Endereço"}</p><p>{a.street}, {a.number}{a.complement ? ` · ${a.complement}` : ""}</p><p>{a.district} · {a.city}/{a.uf} · CEP {a.cep}</p>
        <form action={deleteAddress}><input type="hidden" name="id" value={a.id} /><button className="mt-2 underline">Remover</button></form></li>)}</ul> : <p className="mt-3 text-bone/70">Nenhum endereço salvo.</p>}
      <form action={addAddress} className="mt-6 grid max-w-xl gap-4 sm:grid-cols-2"><h3 className="font-semibold sm:col-span-2">Novo endereço</h3>
        {f("label", "Apelido (casa, trabalho)", false)}{f("cep", "CEP", true, "postal-code")}{f("street", "Rua", true, "address-line1")}{f("number", "Número")}{f("district", "Bairro")}{f("city", "Município", true, "address-level2")}{f("uf", "UF", true, "address-level1")}{f("complement", "Complemento", false)}
        <button className="btn sm:col-span-2">Salvar endereço</button></form></section>
    <section><h2 className="font-display text-2xl">Histórico de compras</h2>
      {orders?.length ? <ul className="mt-4 space-y-4">{orders.map(o => <li key={o.id} className="bg-coal p-4 text-sm">
        <p className="flex flex-wrap justify-between gap-2"><span>Pedido {o.id.slice(0, 8)} · {new Date(o.created_at).toLocaleDateString("pt-BR")}</span><span className="font-semibold">{brl(Number(o.total))}</span></p>
        <p className="text-bone/70">{STATUS_LABEL[o.status]} · Pagamento: {PAY_LABEL[o.payment_status]}{o.tracking_code ? ` · Rastreio ${o.tracking_code}` : ""}</p>
        <ul className="mt-2 text-bone/80">{(o.order_items as Item[]).map(i => <li key={i.id}>{i.qty}× {i.product_name} · {i.size} · {i.color}</li>)}</ul></li>)}</ul> : <p className="mt-3 text-bone/70">Você ainda não fez compras.</p>}</section></div>);
}
