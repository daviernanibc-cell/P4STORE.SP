"use server";
import { redirect } from "next/navigation"; import { z } from "zod"; import { requireUser } from "@/lib/supabase/server";
export async function saveProfile(fd: FormData) {
  const { s, user } = await requireUser();
  const r = z.object({ full_name: z.string().trim().min(2).max(100), phone: z.string().trim().max(20) }).safeParse(Object.fromEntries(fd));
  if (!r.success) redirect("/conta?erro=Confira nome e telefone.");
  const { error } = await s.from("profiles").update(r.data).eq("id", user.id);
  redirect(error ? "/conta?erro=Não foi possível salvar." : "/conta?ok=Dados salvos.");
}
const addr = z.object({ label: z.string().trim().max(30), cep: z.string().transform(v => v.replace(/\D/g, "")).pipe(z.string().length(8)),
  street: z.string().trim().min(2).max(120), number: z.string().trim().min(1).max(10), district: z.string().trim().min(2).max(80),
  city: z.string().trim().min(2).max(80), uf: z.string().trim().length(2).transform(v => v.toUpperCase()), complement: z.string().trim().max(80) });
export async function addAddress(fd: FormData) {
  const { s, user } = await requireUser();
  const r = addr.safeParse(Object.fromEntries(fd)); if (!r.success) redirect("/conta?erro=Confira os campos do endereço (CEP com 8 números, UF com 2 letras).");
  const { error } = await s.from("addresses").insert({ ...r.data, label: r.data.label || null, complement: r.data.complement || null, user_id: user.id });
  redirect(error ? "/conta?erro=Não foi possível salvar o endereço." : "/conta?ok=Endereço salvo.");
}
export async function deleteAddress(fd: FormData) {
  const { s, user } = await requireUser();
  await s.from("addresses").delete().eq("id", String(fd.get("id"))).eq("user_id", user.id);
  redirect("/conta?ok=Endereço removido.");
}
