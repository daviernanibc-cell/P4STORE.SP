import Link from "next/link"; import { listProducts } from "@/lib/products"; import { CATEGORIES, effective } from "@/lib/product-types"; import ProductCard from "@/components/ProductCard";
type SP = { q?: string; categoria?: string; marca?: string; tamanho?: string; max?: string };
export default async function Catalog({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const PRODUCTS = await listProducts();
  const brands = [...new Set(PRODUCTS.map(p => p.brand))];
  const sizes = [...new Set(PRODUCTS.flatMap(p => p.variants.map(v => v.size)))];
  const max = Number(sp.max) || 0, q = (sp.q ?? "").toLowerCase().trim();
  const list = PRODUCTS.filter(p => (!q || `${p.name} ${p.category} ${p.brand}`.toLowerCase().includes(q))
    && (!sp.categoria || p.category === sp.categoria) && (!sp.marca || p.brand === sp.marca)
    && (!sp.tamanho || p.variants.some(v => v.size === sp.tamanho && v.stock > 0)) && (!max || effective(p) <= max));
  return (<div className="mt-6 grid gap-8 md:grid-cols-[220px_1fr]">
    <form className="space-y-4" aria-label="Filtros">
      <input name="q" defaultValue={sp.q} className="input" placeholder="Buscar" aria-label="Buscar" />
      <label className="block text-sm">Categoria<select name="categoria" defaultValue={sp.categoria ?? ""} className="input mt-1"><option value="">Todas</option>{CATEGORIES.map(c => <option key={c}>{c}</option>)}</select></label>
      <label className="block text-sm">Marca<select name="marca" defaultValue={sp.marca ?? ""} className="input mt-1"><option value="">Todas</option>{brands.map(b => <option key={b}>{b}</option>)}</select></label>
      <label className="block text-sm">Tamanho<select name="tamanho" defaultValue={sp.tamanho ?? ""} className="input mt-1"><option value="">Todos</option>{sizes.map(s => <option key={s}>{s}</option>)}</select></label>
      <label className="block text-sm">Preço máximo (R$)<input name="max" type="number" min="0" defaultValue={sp.max} className="input mt-1" /></label>
      <button className="btn w-full">Aplicar filtros</button><Link href="/produtos" className="btn-line w-full">Limpar</Link>
    </form>
    <div>{list.length ? <div className="grid grid-cols-2 gap-4 lg:grid-cols-3">{list.map(p => <ProductCard key={p.id} p={p} />)}</div>
      : <p className="text-bone/70">Nenhum produto com esses filtros. Remova algum filtro para ver mais opções.</p>}</div>
  </div>);
}
