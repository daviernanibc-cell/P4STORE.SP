import Link from "next/link"; import { login } from "@/app/auth/actions";
const ERR: Record<string, string> = { credenciais: "E-mail ou senha incorretos." }; const OK: Record<string, string> = { confirme: "Conta criada. Confirme o e-mail que enviamos e depois entre." };
export default async function Login({ searchParams }: { searchParams: Promise<{ erro?: string; ok?: string; next?: string }> }) {
  const sp = await searchParams;
  return (<div className="mx-auto mt-10 max-w-sm"><h1 className="font-display text-4xl">Entrar</h1>
    {sp.erro && ERR[sp.erro] && <p role="alert" className="mt-4 border border-pepper p-3 text-sm">{ERR[sp.erro]}</p>}
    {sp.ok && OK[sp.ok] && <p role="status" className="mt-4 border border-bone/30 p-3 text-sm">{OK[sp.ok]}</p>}
    <form action={login} className="mt-6 space-y-4"><input type="hidden" name="next" value={sp.next ?? ""} />
      <label className="block text-sm">E-mail<input name="email" type="email" required autoComplete="email" className="input mt-1" /></label>
      <label className="block text-sm">Senha<input name="password" type="password" required autoComplete="current-password" className="input mt-1" /></label>
      <button className="btn w-full">Entrar</button></form>
    <p className="mt-5 text-sm">Ainda não tem conta? <Link href="/cadastro" className="underline">Criar conta</Link></p></div>);
}
