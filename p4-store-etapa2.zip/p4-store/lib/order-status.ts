export const STATUSES = ["aguardando_pagamento", "pago", "em_separacao", "enviado", "entregue", "cancelado"] as const;
export const STATUS_LABEL: Record<string, string> = { aguardando_pagamento: "Aguardando pagamento", pago: "Pago", em_separacao: "Em separação", enviado: "Enviado", entregue: "Entregue", cancelado: "Cancelado" };
export const PAY_LABEL: Record<string, string> = { pendente: "Pendente", aprovado: "Aprovado", recusado: "Recusado", reembolsado: "Reembolsado" };
