import { supabaseServer } from "@/lib/supabase/server"; import type { Product } from "@/lib/product-types";
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const mapProduct = (r: any): Product => ({ id: r.id, slug: r.slug, name: r.name, brand: r.brand, category: r.category, description: r.description, price: Number(r.price),
  promoPrice: r.promo_price == null ? undefined : Number(r.promo_price), images: r.images ?? [], tags: r.tags ?? [],
  variants: (r.product_variants ?? []).map((v: { size: string; color: string; stock: number }) => ({ size: v.size, color: v.color, stock: v.stock })) });
export async function listProducts(): Promise<Product[]> {
  const s = await supabaseServer();
  const { data, error } = await s.from("products").select("*, product_variants(*)").eq("active", true).order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []).map(mapProduct);
}
export async function getProductBySlug(slug: string): Promise<Product | null> {
  const s = await supabaseServer();
  const { data } = await s.from("products").select("*, product_variants(*)").eq("slug", slug).eq("active", true).maybeSingle();
  return data ? mapProduct(data) : null;
}
