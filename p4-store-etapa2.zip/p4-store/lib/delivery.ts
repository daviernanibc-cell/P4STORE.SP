// Regra centralizada de prazos. Valores INICIAIS, a validar com fornecedores/transportadoras.
// Etapa 2: estas zonas passam a ser editáveis pelo painel (banco de dados).
export type Zone = { id: string; label: string; min: number; max: number };
export const ZONES: Record<string, Zone> = {
  capital: { id: "capital", label: "São Paulo (capital)", min: 20, max: 35 },
  sp: { id: "sp", label: "Estado de São Paulo", min: 25, max: 40 },
  sudeste_sul: { id: "sudeste_sul", label: "Sudeste e Sul", min: 30, max: 45 },
  centro_oeste: { id: "centro_oeste", label: "Centro-Oeste", min: 35, max: 50 },
  nordeste: { id: "nordeste", label: "Nordeste", min: 40, max: 55 },
  norte: { id: "norte", label: "Norte", min: 45, max: 60 },
};
const IBGE_SP_CAPITAL = "3550308";
export function zoneFor(uf: string, ibge: string): Zone {
  if (ibge === IBGE_SP_CAPITAL) return ZONES.capital;
  if (uf === "SP") return ZONES.sp;
  if (["RJ", "MG", "ES", "PR", "SC", "RS"].includes(uf)) return ZONES.sudeste_sul;
  if (["GO", "MT", "MS", "DF"].includes(uf)) return ZONES.centro_oeste;
  if (["BA", "SE", "AL", "PE", "PB", "RN", "CE", "PI", "MA"].includes(uf)) return ZONES.nordeste;
  return ZONES.norte;
}
