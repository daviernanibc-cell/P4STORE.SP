import { createServerClient } from "@supabase/ssr"; import { cookies } from "next/headers"; import { redirect, notFound } from "next/navigation";
export async function supabaseServer() {
  const store = await cookies();
  return createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, { cookies: {
    getAll: () => store.getAll(),
    setAll: l => { try { l.forEach(({ name, value, options }) => store.set(name, value, options)); } catch { /* chamado de Server Component: o middleware renova a sessão */ } },
  } });
}
export async function getSessionUser() {
  const s = await supabaseServer();
  const { data: { user } } = await s.auth.getUser();
  if (!user) return { s, user: null, role: null as string | null, name: "" };
  const { data: p } = await s.from("profiles").select("role, full_name").eq("id", user.id).single();
  return { s, user, role: (p?.role ?? "customer") as string, name: (p?.full_name ?? "") as string };
}
export async function requireUser() { const r = await getSessionUser(); if (!r.user) redirect("/login"); return { ...r, user: r.user }; }
export async function requireAdmin() { const r = await requireUser(); if (r.role !== "admin") notFound(); return r; }
