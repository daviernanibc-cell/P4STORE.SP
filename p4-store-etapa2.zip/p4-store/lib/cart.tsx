"use client";
import { createContext, useContext, useEffect, useState, ReactNode } from "react";
export type CartItem = { slug: string; name: string; price: number; size: string; color: string; qty: number };
export const keyOf = (i: Pick<CartItem, "slug" | "size" | "color">) => `${i.slug}|${i.size}|${i.color}`;
type Ctx = { items: CartItem[]; add: (i: CartItem) => void; setQty: (k: string, q: number) => void; remove: (k: string) => void; count: number; subtotal: number };
const C = createContext<Ctx | null>(null);
export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [ready, setReady] = useState(false);
  useEffect(() => { try { setItems(JSON.parse(localStorage.getItem("p4cart") || "[]")); } catch {} setReady(true); }, []);
  useEffect(() => { if (ready) localStorage.setItem("p4cart", JSON.stringify(items)); }, [items, ready]);
  const add = (i: CartItem) => setItems(p => p.some(x => keyOf(x) === keyOf(i)) ? p.map(x => keyOf(x) === keyOf(i) ? { ...x, qty: x.qty + i.qty } : x) : [...p, i]);
  const setQty = (k: string, q: number) => setItems(p => q < 1 ? p.filter(x => keyOf(x) !== k) : p.map(x => keyOf(x) === k ? { ...x, qty: q } : x));
  const remove = (k: string) => setItems(p => p.filter(x => keyOf(x) !== k));
  return <C.Provider value={{ items, add, setQty, remove, count: items.reduce((s, i) => s + i.qty, 0), subtotal: items.reduce((s, i) => s + i.qty * i.price, 0) }}>{children}</C.Provider>;
}
export const useCart = () => { const c = useContext(C); if (!c) throw new Error("CartProvider ausente"); return c; };
