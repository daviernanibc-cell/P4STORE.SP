export const CATEGORIES = ["Camisetas", "Calças", "Moletons", "Jaquetas", "Tênis", "Acessórios"] as const;
export type Tag = "destaque" | "lancamento" | "maisvendido";
export type Variant = { size: string; color: string; stock: number };
export type Product = { id: string; slug: string; name: string; brand: string; category: string; description: string; price: number; promoPrice?: number; images: string[]; variants: Variant[]; tags: Tag[] };
export const effective = (p: Product) => p.promoPrice ?? p.price;
export const available = (p: Product) => p.variants.some(x => x.stock > 0);
export const imageUrl = (path: string) => `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/product-images/${path}`;
