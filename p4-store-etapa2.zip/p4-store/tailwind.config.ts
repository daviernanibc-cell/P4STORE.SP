import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: { extend: {
    colors: { ink: "#0d0a0a", coal: "#1a1515", ash: "#2a2323", bone: "#ececec", pepper: "#d9481f" },
    fontFamily: { display: ["var(--font-display)"], sans: ["var(--font-body)"] },
  } },
} satisfies Config;
