import Link from "next/link"; import { Product, effective, available, imageUrl } from "@/lib/product-types"; import { brl } from "@/lib/format";
export default function ProductCard({ p }: { p: Product }) {
  return (<Link href={`/produto/${p.slug}`} className="group block">
    <div className="relative aspect-[4/5] overflow-hidden bg-coal">
      {p.images[0] ? <img src={imageUrl(p.images[0])} alt={p.name} className="h-full w-full object-cover" loading="lazy" /> : <div className="absolute inset-0 grid place-items-center font-display text-5xl text-bone/10">P4</div>}
      {p.promoPrice && <span className="absolute left-0 top-3 bg-pepper px-2 py-1 text-sm font-semibold text-white">Oferta</span>}
      {!available(p) && <span className="absolute bottom-0 w-full bg-ink/80 p-2 text-center text-sm">Indisponível</span>}</div>
    <p className="mt-3 font-semibold group-hover:text-pepper">{p.name}</p>
    <p className="text-sm text-bone/60">{p.category}</p>
    <p className="mt-1">{p.promoPrice && <span className="mr-2 text-bone/50 line-through">{brl(p.price)}</span>}<span className="font-semibold">{brl(effective(p))}</span></p>
  </Link>);
}
