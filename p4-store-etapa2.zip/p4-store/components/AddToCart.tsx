"use client";
import { useState } from "react"; import Link from "next/link"; import { Product, effective } from "@/lib/product-types"; import { useCart } from "@/lib/cart";
export default function AddToCart({ p }: { p: Product }) {
  const sizes = [...new Set(p.variants.map(v => v.size))], colors = [...new Set(p.variants.map(v => v.color))];
  const [size, setSize] = useState(""), [color, setColor] = useState(""), [done, setDone] = useState(false);
  const { add } = useCart();
  const stock = p.variants.find(v => v.size === size && v.color === color)?.stock ?? 0;
  const ok = size && color && stock > 0;
  const pick = (label: string, opts: string[], val: string, set: (s: string) => void, test: (o: string) => boolean) => (
    <fieldset><legend className="mb-2 text-sm text-bone/70">{label}</legend><div className="flex flex-wrap gap-2">
      {opts.map(o => <button type="button" key={o} disabled={!test(o)} onClick={() => { set(o); setDone(false); }} aria-pressed={val === o}
        className={`min-w-12 border px-3 py-2 disabled:opacity-30 ${val === o ? "border-pepper bg-pepper" : "border-bone/30 hover:border-bone"}`}>{o}</button>)}</div></fieldset>);
  return (<div className="space-y-5">
    {pick("Tamanho", sizes, size, setSize, o => p.variants.some(v => v.size === o && v.stock > 0))}
    {pick("Cor", colors, color, setColor, o => p.variants.some(v => v.color === o && v.stock > 0))}
    {size && color && stock === 0 && <p className="text-sm text-pepper">Essa combinação está esgotada.</p>}
    <button className="btn w-full" disabled={!ok} onClick={() => { add({ slug: p.slug, name: p.name, price: effective(p), size, color, qty: 1 }); setDone(true); }}>Adicionar ao carrinho</button>
    {done && <p role="status" className="text-sm">Adicionado. <Link href="/carrinho" className="underline">Ver carrinho</Link></p>}
  </div>);
}
