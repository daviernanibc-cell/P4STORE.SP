import Link from "next/link"; import { CATEGORIES } from "@/lib/product-types"; import CartLink from "./CartLink"; import { getSessionUser } from "@/lib/supabase/server";
export default async function Header() {
  const { user, role } = await getSessionUser();
  return (<header className="sticky top-0 z-20 border-b border-bone/10 bg-ink/95 backdrop-blur">
    <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
      <Link href="/" aria-label="P4 STORE, página inicial"><img src="/logo.png" alt="Pepper 4 Store" className="h-12 w-12 object-cover" /></Link>
      <form action="/produtos" className="flex flex-1"><input name="q" className="input" placeholder="Buscar produtos" aria-label="Buscar produtos" /><button className="btn px-4">Buscar</button></form>
      <CartLink />
    </div>
    <nav className="mx-auto flex max-w-6xl gap-5 overflow-x-auto px-4 pb-3 text-sm" aria-label="Categorias">
      <Link href="/produtos" className="whitespace-nowrap hover:text-pepper">Tudo</Link>
      {CATEGORIES.map(c => <Link key={c} href={`/produtos?categoria=${encodeURIComponent(c)}`} className="whitespace-nowrap hover:text-pepper">{c}</Link>)}
      <span className="ml-auto flex gap-5 pl-5">
        {role === "admin" && <Link href="/admin" className="whitespace-nowrap font-semibold text-pepper">Admin</Link>}
        {user ? <Link href="/conta" className="whitespace-nowrap hover:text-pepper">Minha conta</Link> : <Link href="/login" className="whitespace-nowrap hover:text-pepper">Entrar</Link>}
      </span>
    </nav></header>);
}
