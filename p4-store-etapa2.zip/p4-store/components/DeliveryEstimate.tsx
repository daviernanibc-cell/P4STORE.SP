"use client";
import { useState } from "react";
import { zoneFor } from "@/lib/delivery";
export default function DeliveryEstimate() {
  const [cep, setCep] = useState(""); const [msg, setMsg] = useState(""); const [busy, setBusy] = useState(false);
  async function check() {
    const c = cep.replace(/\D/g, "");
    if (c.length !== 8) return setMsg("Digite um CEP com 8 números.");
    setBusy(true); setMsg("");
    try {
      const r = await fetch(`https://viacep.com.br/ws/${c}/json/`); const d = await r.json();
      if (d.erro) return setMsg("CEP não encontrado. Confira os números.");
      const z = zoneFor(d.uf, d.ibge);
      setMsg(`Entrega estimada para ${d.localidade}/${d.uf}: ${z.min} a ${z.max} dias corridos. Estimativa sujeita à confirmação no pedido.`);
    } catch { setMsg("Não foi possível consultar o CEP agora. Tente novamente."); } finally { setBusy(false); }
  }
  return (<div className="space-y-2">
    <div className="flex gap-2"><input className="input" inputMode="numeric" placeholder="Seu CEP" value={cep} onChange={e => setCep(e.target.value)} aria-label="CEP" />
      <button type="button" className="btn-line shrink-0" onClick={check} disabled={busy}>{busy ? "Buscando" : "Calcular prazo"}</button></div>
    {msg && <p className="text-sm text-bone/70" role="status">{msg}</p>}
  </div>);
}
