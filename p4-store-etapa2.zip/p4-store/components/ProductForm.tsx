"use client";
import { useState } from "react"; import { saveProduct } from "@/app/admin/produtos/actions"; import { supabaseBrowser } from "@/lib/supabase/client"; import { CATEGORIES, imageUrl } from "@/lib/product-types";
export type FormProduct = { id: string | null; name: string; brand: string; category: string; description: string; price: string; promo_price: string; active: boolean; tags: string[]; images: string[]; variants: { size: string; color: string; stock: number }[] };
const TAGS: [string, string][] = [["destaque", "Em destaque"], ["lancamento", "Lançamento"], ["maisvendido", "Mais vendido"]];
export default function ProductForm({ initial }: { initial: FormProduct }) {
  const [f, setF] = useState(initial); const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  const set = <K extends keyof FormProduct>(k: K, v: FormProduct[K]) => setF(p => ({ ...p, [k]: v }));
  async function upload(files: FileList | null) {
    if (!files) return; setBusy(true); setErr(""); const sb = supabaseBrowser(); const added: string[] = [];
    for (const file of Array.from(files)) {
      if (!["image/jpeg", "image/png", "image/webp"].includes(file.type) || file.size > 5 * 1024 * 1024) { setErr("Use JPG, PNG ou WebP de até 5 MB."); continue; }
      const path = `products/${crypto.randomUUID()}.${file.type.split("/")[1]}`;
      const { error } = await sb.storage.from("product-images").upload(path, file, { contentType: file.type });
      if (error) setErr(`Falha no envio: ${error.message}`); else added.push(path);
    }
    setF(p => ({ ...p, images: [...p.images, ...added] })); setBusy(false);
  }
  const setV = (i: number, k: "size" | "color" | "stock", v: string) => set("variants", f.variants.map((x, j) => j === i ? { ...x, [k]: k === "stock" ? Math.max(0, Number(v) || 0) : v } : x));
  return (<form action={saveProduct} className="grid max-w-2xl gap-5">
    <input type="hidden" name="payload" value={JSON.stringify({ ...f, price: f.price, promo_price: f.promo_price })} />
    <label className="block text-sm">Nome<input className="input mt-1" required value={f.name} onChange={e => set("name", e.target.value)} /></label>
    <div className="grid gap-5 sm:grid-cols-2">
      <label className="block text-sm">Marca<input className="input mt-1" required value={f.brand} onChange={e => set("brand", e.target.value)} /></label>
      <label className="block text-sm">Categoria<select className="input mt-1" required value={f.category} onChange={e => set("category", e.target.value)}><option value="">Escolha</option>{CATEGORIES.map(c => <option key={c}>{c}</option>)}</select></label>
      <label className="block text-sm">Preço (R$)<input className="input mt-1" required type="number" step="0.01" min="0.01" value={f.price} onChange={e => set("price", e.target.value)} /></label>
      <label className="block text-sm">Preço promocional (opcional)<input className="input mt-1" type="number" step="0.01" min="0.01" value={f.promo_price} onChange={e => set("promo_price", e.target.value)} /></label></div>
    <label className="block text-sm">Descrição<textarea className="input mt-1 min-h-28" value={f.description} onChange={e => set("description", e.target.value)} /></label>
    <fieldset><legend className="mb-2 text-sm text-bone/70">Vitrines da home</legend><div className="flex flex-wrap gap-4">{TAGS.map(([k, l]) => <label key={k} className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.tags.includes(k)} onChange={e => set("tags", e.target.checked ? [...f.tags, k] : f.tags.filter(t => t !== k))} />{l}</label>)}</div></fieldset>
    <fieldset><legend className="mb-2 text-sm text-bone/70">Fotos (a primeira é a capa)</legend>
      <div className="flex flex-wrap gap-3">{f.images.map((im, i) => <div key={im} className="w-24"><img src={imageUrl(im)} alt={`Foto ${i + 1}`} className="aspect-square w-24 object-cover" />
        <div className="mt-1 flex justify-between text-xs">{i > 0 ? <button type="button" className="underline" onClick={() => set("images", [im, ...f.images.filter(x => x !== im)])}>Capa</button> : <span>Capa</span>}<button type="button" className="underline" onClick={() => set("images", f.images.filter(x => x !== im))}>Tirar</button></div></div>)}</div>
      <input type="file" accept="image/jpeg,image/png,image/webp" multiple disabled={busy || f.images.length >= 8} onChange={e => { upload(e.target.files); e.target.value = ""; }} className="mt-3 text-sm" />
      {busy && <p className="mt-2 text-sm" role="status">Enviando fotos…</p>}{err && <p className="mt-2 text-sm text-pepper" role="alert">{err}</p>}</fieldset>
    <fieldset><legend className="mb-2 text-sm text-bone/70">Estoque por tamanho e cor</legend><div className="space-y-2">
      {f.variants.map((v, i) => <div key={i} className="grid grid-cols-[1fr_1fr_5rem_auto] items-center gap-2">
        <input className="input" placeholder="Tamanho" aria-label="Tamanho" value={v.size} onChange={e => setV(i, "size", e.target.value)} /><input className="input" placeholder="Cor" aria-label="Cor" value={v.color} onChange={e => setV(i, "color", e.target.value)} />
        <input className="input" type="number" min="0" aria-label="Quantidade em estoque" value={v.stock} onChange={e => setV(i, "stock", e.target.value)} />
        <button type="button" className="px-2 text-sm underline" onClick={() => set("variants", f.variants.filter((_, j) => j !== i))}>Remover</button></div>)}</div>
      <button type="button" className="btn-line mt-3" onClick={() => set("variants", [...f.variants, { size: "", color: "", stock: 0 }])}>Adicionar variação</button></fieldset>
    <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.active} onChange={e => set("active", e.target.checked)} />Visível na loja</label>
    <button className="btn" disabled={busy}>Salvar produto</button></form>);
}
