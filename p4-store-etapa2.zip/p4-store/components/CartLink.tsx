"use client";
import Link from "next/link"; import { useCart } from "@/lib/cart";
export default function CartLink() { const { count } = useCart();
  return <Link href="/carrinho" className="relative px-3 py-2 font-semibold hover:text-pepper" aria-label={`Carrinho, ${count} itens`}>Carrinho{count > 0 && <span className="ml-1.5 bg-pepper px-1.5 text-sm text-white">{count}</span>}</Link>; }
