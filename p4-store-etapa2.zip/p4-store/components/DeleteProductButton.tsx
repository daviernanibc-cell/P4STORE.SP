"use client";
import { deleteProduct } from "@/app/admin/produtos/actions";
export default function DeleteProductButton({ id, name }: { id: string; name: string }) {
  return (<form action={deleteProduct} onSubmit={e => { if (!confirm(`Excluir "${name}" e suas fotos? Isso não pode ser desfeito.`)) e.preventDefault(); }}>
    <input type="hidden" name="id" value={id} /><button className="text-pepper underline">Excluir</button></form>);
}
