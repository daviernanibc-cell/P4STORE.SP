export default function Footer() {
  return (<footer className="mt-20 border-t border-bone/10 py-10 text-sm text-bone/70"><div className="mx-auto grid max-w-6xl gap-6 px-4 sm:grid-cols-3">
    <div><p className="font-display text-xl text-bone">P4 STORE</p><p className="mt-2">Streetwear com produtos próprios.</p></div>
    <div><p className="font-semibold text-bone">Contato</p><p className="mt-2">Defina e-mail e WhatsApp da loja em components/Footer.tsx.</p></div>
    <div><p className="font-semibold text-bone">Políticas</p><p className="mt-2">Trocas, privacidade e termos: páginas a publicar antes do lançamento.</p></div>
  </div></footer>);
}
