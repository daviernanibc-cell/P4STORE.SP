-- P4 STORE, Etapa 2. Rode inteiro no SQL Editor do Supabase.
create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text, full_name text, phone text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now());

create function public.is_admin() returns boolean language sql security definer stable set search_path = public as
$$ select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin') $$;

create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as
$$ begin insert into public.profiles (id, email, full_name) values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name','')); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- Papel e e-mail só mudam pelo SQL Editor (auth.uid() é nulo ali). Nenhum usuário do app consegue se promover.
create function public.protect_profile() returns trigger language plpgsql security definer set search_path = public as
$$ begin
  if auth.uid() is not null and (new.role is distinct from old.role or new.id <> old.id or new.email is distinct from old.email) then
    raise exception 'Campo protegido'; end if;
  return new; end $$;
create trigger protect_profile before update on public.profiles for each row execute function public.protect_profile();

create table public.products (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null check (char_length(name) between 2 and 120),
  brand text not null,
  category text not null check (category in ('Camisetas','Calças','Moletons','Jaquetas','Tênis','Acessórios')),
  description text not null default '',
  price numeric(10,2) not null check (price > 0),
  promo_price numeric(10,2) check (promo_price is null or (promo_price > 0 and promo_price < price)),
  images text[] not null default '{}',
  tags text[] not null default '{}',
  active boolean not null default true,
  created_at timestamptz not null default now());
create index on public.products (category);

create table public.product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  size text not null, color text not null,
  stock integer not null default 0 check (stock >= 0),
  unique (product_id, size, color));

create table public.addresses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  label text, cep text not null check (cep ~ '^[0-9]{8}$'),
  street text not null, number text not null, district text not null,
  city text not null, uf char(2) not null, complement text,
  created_at timestamptz not null default now());
create index on public.addresses (user_id);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  status text not null default 'aguardando_pagamento' check (status in ('aguardando_pagamento','pago','em_separacao','enviado','entregue','cancelado')),
  payment_status text not null default 'pendente' check (payment_status in ('pendente','aprovado','recusado','reembolsado')),
  subtotal numeric(10,2) not null, shipping_cost numeric(10,2) not null default 0, total numeric(10,2) not null,
  customer_name text not null, customer_phone text,
  ship_cep text not null, ship_street text not null, ship_number text not null, ship_district text not null,
  ship_city text not null, ship_uf char(2) not null, ship_complement text,
  delivery_min_days int, delivery_max_days int,
  tracking_code text,  -- só será preenchido a partir da integração real (Etapa 3)
  created_at timestamptz not null default now());
create index on public.orders (user_id);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  variant_id uuid references public.product_variants(id) on delete set null,
  product_name text not null, size text not null, color text not null,
  unit_price numeric(10,2) not null, qty integer not null check (qty > 0));
create index on public.order_items (order_id);

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.product_variants enable row level security;
alter table public.addresses enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

create policy profiles_select on public.profiles for select to authenticated using (id = auth.uid() or public.is_admin());
create policy profiles_update on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy products_read on public.products for select using (active or public.is_admin());
create policy products_admin_ins on public.products for insert to authenticated with check (public.is_admin());
create policy products_admin_upd on public.products for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy products_admin_del on public.products for delete to authenticated using (public.is_admin());

create policy variants_read on public.product_variants for select using (exists (select 1 from public.products p where p.id = product_id and (p.active or public.is_admin())));
create policy variants_admin_ins on public.product_variants for insert to authenticated with check (public.is_admin());
create policy variants_admin_upd on public.product_variants for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy variants_admin_del on public.product_variants for delete to authenticated using (public.is_admin());

create policy addr_own on public.addresses for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy addr_admin_read on public.addresses for select to authenticated using (public.is_admin());

-- Pedidos: cliente só lê os próprios; só admin altera. Criação de pedidos fica com o servidor (Etapa 3).
create policy orders_read on public.orders for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy orders_admin_upd on public.orders for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy items_read on public.order_items for select to authenticated using (exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_admin())));

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('product-images','product-images', true, 5242880, array['image/jpeg','image/png','image/webp']) on conflict (id) do nothing;
create policy img_read on storage.objects for select using (bucket_id = 'product-images');
create policy img_admin_ins on storage.objects for insert to authenticated with check (bucket_id = 'product-images' and public.is_admin());
create policy img_admin_upd on storage.objects for update to authenticated using (bucket_id = 'product-images' and public.is_admin());
create policy img_admin_del on storage.objects for delete to authenticated using (bucket_id = 'product-images' and public.is_admin());

-- Depois de criar SUA conta no site, torne-se o proprietário (troque o e-mail):
-- update public.profiles set role = 'admin' where email = 'SEU_EMAIL@exemplo.com';
